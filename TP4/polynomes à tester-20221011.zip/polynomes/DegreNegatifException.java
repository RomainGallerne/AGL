package polynomes;

public class DegreNegatifException extends RuntimeException {
    public DegreNegatifException(String s) {
        super(s);
    }
}
